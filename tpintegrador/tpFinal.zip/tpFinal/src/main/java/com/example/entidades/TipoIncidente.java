package com.example.entidades;

import lombok.Getter;
import lombok.Setter;

public class TipoIncidente {
    private @Setter @Getter int idTipoIncidente;
    private @Setter @Getter String TipodeIncidente;

     public TipoIncidente() {
         int idTipoIncidente= 0;
         String TipodeIncidente= "";

     }
}

package com.example.entidades;

import lombok.Getter;
import lombok.Setter;

public class Operador {
    private int @Setter @Getter idOperador,
    private String @Setter @Getter  Nombre, Apellido;

     public Operador() {
         idOperador= 0;
         String Nombre= "";
         String Apellido= "";

     }
}

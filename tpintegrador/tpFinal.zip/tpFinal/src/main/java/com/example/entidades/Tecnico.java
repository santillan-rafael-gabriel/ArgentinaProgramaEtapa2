package com.example.entidades;

import lombok.Getter;
import lombok.Setter;

public class Tecnico {
    private @Setter @Getter String EstadoTecnico, IncidenteResueltos, Nombre, Apellido, Cuil;

     public Tecnico() {
         String EstadoTecnico= "";
         String IncidenteResueltos= "";
         String Nombre= "";
         String Apellido= "";
         String Cuil= "";
     }
}

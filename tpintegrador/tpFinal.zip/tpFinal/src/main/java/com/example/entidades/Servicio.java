package com.example.entidades;

import lombok.Getter;
import lombok.Setter;

public class Servicio {
    private @Setter @Getter String TipodeServicio, Empresa;

    public Servicio() {
        String TipodeServicio= "";
        String Empresa= "";

    }
}

package com.example.entidades;

import lombok.Getter;
import lombok.Setter;

public class  MesaAyuda {
    private @Setter @Getter int idMesaAyuda;
    private @Setter @Getter int NumerodeReclamo;

    public MesaAyuda() {
        idMesaAyuda= 0;
        NumerodeReclamo= 0;

    }


}

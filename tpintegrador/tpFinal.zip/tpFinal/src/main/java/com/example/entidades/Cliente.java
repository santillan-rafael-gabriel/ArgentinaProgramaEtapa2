package com.example.entidades;

import lombok.Getter;
import lombok.Setter;

public class Cliente {
    private String @Setter @Getter Nombre, Apellido, RazonSocial;
    private @Setter @Getter String Cuil;
    private @Getter @Setter int idCliente;

    public Cliente() {
        String Nombre= "";
        String Apellido= "";
        String RazonSocial= "";
        String Cuil= "";
        int idCliente= 0;

    }

}
